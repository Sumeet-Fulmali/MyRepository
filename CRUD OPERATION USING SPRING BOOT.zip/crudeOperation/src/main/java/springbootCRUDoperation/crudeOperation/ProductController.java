package springbootCRUDoperation.crudeOperation;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	ProductService ps = new ProductService();
	
	@GetMapping("/Product")
	public ArrayList<Product> getAllProduct() {
		return ps.getAllProduct();
	}
	
	@PostMapping("/AddProduct")
	public ArrayList<Product> AddProduct() {
		
		return ps.AddProduct();		
	}
	
	@PutMapping("/updateProduct")
	public ArrayList<Product> updateProduct(){
	
		return ps.updateProduct();
	}
	
	
	@DeleteMapping("/deleteProduct")
	
	public ArrayList<Product> deleteProduct() {
	return	ps.deleteProduct();
		
	}
}
