package springbootCRUDoperation.crudeOperation;

import java.util.ArrayList;

public class ProductService {
	
	static ArrayList<Product> list = new ArrayList<>();
	
	
		
		public static ArrayList<Product> getdata() {
			Product p1 = new Product(1, "A", 5, 100);
			Product p2 = new Product(2, "B", 6, 200);
			Product p3 = new Product(3, "C", 7, 400);
			Product p4 = new Product(4, "D", 8, 300);
			
			list.add(p1);
			list.add(p2);
			list.add(p3);
			list.add(p4);
			return list;
			
		}
	
	public static ArrayList<Product>  getAllProduct() {
		return getdata();
	}
	
	
	public static ArrayList<Product> AddProduct() {
		
		Product p5 = new Product(5,	 "E", 9, 400);
		list.add(p5);
		return list;
	}
	
	public static ArrayList<Product> updateProduct() {
		
		list.set(1, new Product(6, "W", 3, 3000));
		return list;
	}
	
	public static ArrayList<Product> deleteProduct() {
		list.removeAll(list);
		return list;
	}
}
